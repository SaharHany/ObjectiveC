//
//  ClassA.m
//  Lab1
//
//  Created by JETS Mobile Lab on 4/10/19.
//  Copyright © 2019 ITI. All rights reserved.
//

#import "ClassA.h"

@implementation ClassA
-(void) methodA{
    printf("inside methodA");
}
@end
