//
//  ClassB.h
//  Lab1
//
//  Created by JETS Mobile Lab on 4/10/19.
//  Copyright © 2019 ITI. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ClassA.h"
NS_ASSUME_NONNULL_BEGIN

@interface ClassB : ClassA
-(void) methodB;
@end

NS_ASSUME_NONNULL_END
