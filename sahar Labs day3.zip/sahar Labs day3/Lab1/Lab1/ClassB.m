//
//  ClassB.m
//  Lab1
//
//  Created by JETS Mobile Lab on 4/10/19.
//  Copyright © 2019 ITI. All rights reserved.
//

#import "ClassB.h"

@implementation ClassB
-(void) methodB{
    printf("inside methodB");
}
@end
