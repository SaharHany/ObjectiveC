//
//  MyClass.m
//  Lab1
//
//  Created by JETS Mobile Lab on 4/10/19.
//  Copyright © 2019 ITI. All rights reserved.
//

#import "MyClass.h"

@implementation MyClass
-(void) myMethod{
    printf("inside myMethod");
}
@end
