//
//  Calculator+SquaringCategory.h
//  SimpleCalculator
//
//  Created by JETS Mobile Lab on 4/10/19.
//  Copyright © 2019 Sahar. All rights reserved.
//

#import "Calculator.h"

NS_ASSUME_NONNULL_BEGIN

@interface Calculator (SquaringCategory)

+(void) sqr : (int)  x;

@end

NS_ASSUME_NONNULL_END
